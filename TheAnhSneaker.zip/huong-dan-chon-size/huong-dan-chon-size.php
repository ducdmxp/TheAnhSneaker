<!DOCTYPE html>
<html lang="vi">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Hướng Dẫn Chọn Size Giày Chuẩn - TheAnhSneaker</title>
    <link rel="icon" type="image/png" href="./img/favicon.png" />
    <meta
      name="description"
      content="Hướng dẫn cách đo chân và chọn size giày sneaker Nike, Adidas, New Balance chuẩn nhất tại TheAnhSneaker để có đôi giày vừa vặn hoàn hảo."
    />

    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;700;900&display=swap"
      rel="stylesheet"
    />

    <style>
      /* Biến màu và font chữ chung */
      :root {
        --primary-color: #111111;
        --secondary-color: #ffffff;
        --accent-color: #ff4500;
        --text-color: #333;
        --font-family: "Be Vietnam Pro", sans-serif;
      }

      /* Reset và Style cơ bản */
      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
      }

      body {
        font-family: var(--font-family);
        line-height: 1.6;
        color: var(--text-color);
        background-color: #f7f7f7;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
      }

      .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 20px;
      }

      a {
        color: var(--accent-color);
        text-decoration: none;
      }

      /* Style cho Header và Logo */
      .policy-header {
        background-color: var(--secondary-color);
        padding: 15px 0;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        text-align: center;
      }
      .policy-header .logo {
        font-size: 1.5rem;
        font-weight: 900;
        background: linear-gradient(
          45deg,
          var(--accent-color),
          #ff8c00,
          #ff4500
        );
        -webkit-background-clip: text;
        background-clip: text;
        color: transparent;
        -webkit-text-fill-color: transparent;
        display: inline-block;
      }

      /* Style cho nội dung chính */
      .policy-container {
        max-width: 800px;
        margin: 40px auto;
        padding: 40px;
        background-color: var(--secondary-color);
        border-radius: 15px;
        box-shadow: 0 5px 25px rgba(0, 0, 0, 0.07);
      }
      .policy-container h1 {
        font-size: 2rem;
        text-align: center;
        margin-bottom: 30px;
        font-weight: 900;
        color: var(--primary-color);
      }
      .policy-container h2 {
        font-size: 1.5rem;
        margin-top: 30px;
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 2px solid var(--accent-color);
        text-align: left;
        font-weight: 700;
      }
      .policy-container p,
      .policy-container li {
        line-height: 1.8;
        color: #555;
      }
      .policy-container ul,
      .policy-container ol {
        padding-left: 20px;
        margin-bottom: 15px;
      }
      .policy-container li {
        margin-bottom: 10px;
      }

      /* Style cho ảnh minh họa */
      .illustration-img {
        max-width: 100%;
        height: auto;
        border-radius: 8px;
        margin: 20px auto;
        display: block;
        border: 1px solid #eee;
      }

      /* Style cho bảng size */
      .size-chart {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
        font-size: 0.95rem;
      }
      .size-chart th,
      .size-chart td {
        border: 1px solid #e5e5e5;
        padding: 10px 12px;
        text-align: center;
      }
      .size-chart th {
        background-color: #f7f7f7;
        font-weight: 700;
      }
      .size-chart tr:nth-child(even) {
        background-color: #fcfcfc;
      }

      /* Nút quay về trang chủ */
      .back-to-home {
        display: inline-block;
        margin-top: 40px;
        padding: 12px 25px;
        background-color: var(--primary-color);
        color: var(--secondary-color);
        border-radius: 50px;
        text-decoration: none;
        font-weight: 500;
        transition: background-color 0.3s ease;
      }
      .back-to-home:hover {
        background-color: var(--accent-color);
      }

      /* Footer */
      .policy-footer {
        text-align: center;
        padding: 20px;
        margin-top: 40px;
        color: #888;
      }

      /* Tương thích với di động */
      @media (max-width: 767px) {
        .policy-container {
          margin: 20px 15px;
          padding: 25px;
        }
        .policy-container h1 {
          font-size: 1.6rem;
        }
        .policy-container h2 {
          font-size: 1.3rem;
        }
        .size-chart {
          font-size: 0.85rem;
        }
        .size-chart th,
        .size-chart td {
          padding: 8px 5px;
        }
      }
    </style>
  </head>
  <body>
    <header class="policy-header">
      <div class="container">
        <a href="/" class="logo">TheAnhSneaker</a>
      </div>
    </header>

    <main>
      <div class="policy-container">
        <h1>Hướng Dẫn Chọn Size Giày Chuẩn Xác</h1>
        <p>
          Chọn đúng size giày là bước quan trọng nhất để đảm bảo sự thoải mái
          cho đôi chân và tránh các thủ tục đổi trả không đáng có. Hãy cùng
          TheAnhSneaker thực hiện 3 bước đơn giản dưới đây nhé!
        </p>

        <h2>Bước 1: Chuẩn Bị Dụng Cụ</h2>
        <ul>
          <li>Một tờ giấy trắng (to hơn bàn chân của bạn).</li>
          <li>Một cây bút.</li>
          <li>Một chiếc thước kẻ hoặc thước dây.</li>
        </ul>

        <h2>Bước 2: Tiến Hành Đo Chân</h2>
        <ol>
          <li>Đặt tờ giấy xuống sàn nhà phẳng, sát vào một bức tường.</li>
          <li>Đứng thẳng trên tờ giấy, gót chân chạm nhẹ vào tường.</li>
          <li>
            Dùng bút vạch một đường thẳng ngay trước đầu ngón chân dài nhất của
            bạn.
          </li>
          <li>
            Dùng thước đo khoảng cách từ mép giấy (chỗ gót chân chạm tường) đến
            vạch vừa kẻ. Ghi lại con số này (đơn vị cm).
          </li>
        </ol>

        <p>
          <strong>Mẹo nhỏ:</strong> Bạn nên đo vào cuối ngày vì lúc này chân có
          xu hướng giãn nở to nhất. Hãy đo cả hai bàn chân và chọn số đo của
          chân dài hơn nhé!
        </p>

        <h2>Bước 3: Tra Cứu Bảng Size</h2>
        <p>
          Sau khi có được số đo chiều dài chân, bạn hãy cộng thêm khoảng
          <strong>0.5cm - 1cm</strong> (phần dư cho thoải mái) rồi so sánh với
          cột "Chiều Dài Chân" trong bảng dưới đây để tìm ra size giày phù hợp.
        </p>

        <table class="size-chart">
          <thead>
            <tr>
              <th>Chiều Dài Chân (cm)</th>
              <th>Size VN/EUR</th>
              <th>Size US</th>
              <th>Size UK</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>22.5 - 23.0</td>
              <td>36 - 36.5</td>
              <td>5 - 5.5</td>
              <td>4 - 4.5</td>
            </tr>
            <tr>
              <td>23.5</td>
              <td>37.5</td>
              <td>6.5</td>
              <td>5</td>
            </tr>
            <tr>
              <td>24.0</td>
              <td>38</td>
              <td>7</td>
              <td>5.5</td>
            </tr>
            <tr>
              <td>24.5</td>
              <td>38.5</td>
              <td>7.5</td>
              <td>6</td>
            </tr>
            <tr>
              <td>25.0</td>
              <td>39</td>
              <td>8</td>
              <td>6.5</td>
            </tr>
            <tr>
              <td>25.5</td>
              <td>40</td>
              <td>8.5</td>
              <td>7</td>
            </tr>
            <tr>
              <td>26.0</td>
              <td>40.5</td>
              <td>9</td>
              <td>7.5</td>
            </tr>
            <tr>
              <td>26.5</td>
              <td>41</td>
              <td>9.5</td>
              <td>8</td>
            </tr>
            <tr>
              <td>27.0</td>
              <td>42</td>
              <td>10</td>
              <td>8.5</td>
            </tr>
            <tr>
              <td>27.5</td>
              <td>42.5</td>
              <td>10.5</td>
              <td>9</td>
            </tr>
            <tr>
              <td>28.0</td>
              <td>43</td>
              <td>11</td>
              <td>9.5</td>
            </tr>
            <tr>
              <td>28.5</td>
              <td>44</td>
              <td>11.5</td>
              <td>10</td>
            </tr>
            <tr>
              <td>29.0</td>
              <td>45</td>
              <td>12</td>
              <td>11</td>
            </tr>
          </tbody>
        </table>

        <h2>Lưu Ý Quan Trọng</h2>
        <ul>
          <li>
            Bảng size trên chỉ mang tính chất tham khảo tương đối. Size giày có
            thể thay đổi một chút tùy thuộc vào form của từng mẫu giày và từng
            thương hiệu (Nike, Adidas, New Balance...).
          </li>
          <li>
            Nếu bàn chân của bạn bè ngang, hãy cân nhắc chọn lớn hơn 0.5 đến 1
            size so với bảng.
          </li>
          <li>
            Để được tư vấn chính xác nhất, đừng ngần ngại liên hệ với
            TheAnhSneaker qua Hotline/Zalo <strong>0981.936.021</strong> nhé!
          </li>
        </ul>

        <div style="text-align: center">
          <a href="/" class="back-to-home">Quay Lại Trang Chủ</a>
        </div>
      </div>
    </main>

    <footer class="policy-footer">
      <p>© 2025 Bản quyền thuộc về TheAnhSneaker.</p>
    </footer>
  </body>
</html>
