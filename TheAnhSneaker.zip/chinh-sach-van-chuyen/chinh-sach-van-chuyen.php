<!DOCTYPE html>
<html lang="vi">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Chính Sách Vận Chuyển - TheAnhSneaker</title>
    <link rel="icon" type="image/png" href="./img/favicon.png" />
    <meta
      name="description"
      content="TheAnhSneaker giao hàng COD toàn quốc siêu tốc, đồng giá chỉ 30K. Freeship cho đơn hàng từ 1.000.000Đ. Xem chi tiết thời gian và chính sách vận chuyển."
    />

    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;700;900&display=swap"
      rel="stylesheet"
    />

    <style>
      /* Biến màu và font chữ chung từ trang chủ */
      :root {
        --primary-color: #111111;
        --secondary-color: #ffffff;
        --accent-color: #ff4500;
        --text-color: #333;
        --font-family: "Be Vietnam Pro", sans-serif;
      }

      /* Reset và Style cơ bản */
      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
      }

      body {
        font-family: var(--font-family);
        line-height: 1.6;
        color: var(--text-color);
        background-color: #f7f7f7;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
      }

      .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 20px;
      }

      a {
        color: var(--accent-color);
        text-decoration: none;
      }

      /* Style cho Header và Logo */
      .policy-header {
        background-color: var(--secondary-color);
        padding: 15px 0;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        text-align: center;
      }
      .policy-header .logo {
        font-size: 1.5rem;
        font-weight: 900;
        background: linear-gradient(
          45deg,
          var(--accent-color),
          #ff8c00,
          #ff4500
        );
        -webkit-background-clip: text;
        background-clip: text;
        color: transparent;
        -webkit-text-fill-color: transparent;
        display: inline-block;
      }

      /* Style cho nội dung chính sách */
      .policy-container {
        max-width: 800px;
        margin: 40px auto;
        padding: 40px;
        background-color: var(--secondary-color);
        border-radius: 15px;
        box-shadow: 0 5px 25px rgba(0, 0, 0, 0.07);
      }
      .policy-container h1 {
        font-size: 2rem;
        text-align: center;
        margin-bottom: 30px;
        font-weight: 900;
        color: var(--primary-color);
      }
      .policy-container h2 {
        font-size: 1.5rem;
        margin-top: 30px;
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 2px solid var(--accent-color);
        text-align: left;
        font-weight: 700;
      }
      .policy-container p,
      .policy-container li {
        line-height: 1.8;
        color: #555;
      }
      .policy-container ul,
      .policy-container ol {
        padding-left: 20px;
        margin-bottom: 15px;
      }
      .policy-container li {
        margin-bottom: 10px;
      }

      /* Nút quay về trang chủ */
      .back-to-home {
        display: inline-block;
        margin-top: 40px;
        padding: 12px 25px;
        background-color: var(--primary-color);
        color: var(--secondary-color);
        border-radius: 50px;
        text-decoration: none;
        font-weight: 500;
        transition: background-color 0.3s ease;
      }
      .back-to-home:hover {
        background-color: var(--accent-color);
      }

      /* Footer */
      .policy-footer {
        text-align: center;
        padding: 20px;
        margin-top: 40px;
        color: #888;
      }

      /* Tương thích với di động */
      @media (max-width: 767px) {
        .policy-container {
          margin: 20px 15px;
          padding: 25px;
        }
        .policy-container h1 {
          font-size: 1.6rem;
        }
        .policy-container h2 {
          font-size: 1.3rem;
        }
      }
    </style>
  </head>
  <body>
    <header class="policy-header">
      <div class="container">
        <a href="/" class="logo">TheAnhSneaker</a>
      </div>
    </header>

    <main>
      <div class="policy-container">
        <h1>Chính Sách Vận Chuyển</h1>
        <p>
          TheAnhSneaker cam kết mang những đôi giày chất lượng đến tay khách
          hàng một cách nhanh chóng và an toàn nhất. Chúng tôi hợp tác với các
          đơn vị vận chuyển uy tín để đảm bảo trải nghiệm mua sắm của bạn được
          trọn vẹn.
        </p>

        <h2>1. Phạm Vi Giao Hàng</h2>
        <p>
          TheAnhSneaker hỗ trợ giao hàng trên toàn lãnh thổ Việt Nam. Dù bạn ở
          đâu, chúng tôi đều sẵn sàng phục vụ.
        </p>

        <h2>2. Thời Gian Giao Hàng (Dự kiến)</h2>
        <p>
          Thời gian giao hàng được tính từ lúc đơn hàng của bạn được xác nhận
          thành công:
        </p>
        <ul>
          <li>
            <strong>Khu vực nội thành Hà Nội:</strong> Từ 1 - 2 ngày làm việc.
          </li>
          <li>
            <strong>Các tỉnh thành Miền Bắc:</strong> Từ 2 - 3 ngày làm việc.
          </li>
          <li>
            <strong>Các tỉnh thành Miền Trung & Miền Nam:</strong> Từ 3 - 5 ngày
            làm việc.
          </li>
        </ul>
        <p>
          <strong>Lưu ý:</strong> Thời gian trên là dự kiến và không bao gồm Chủ
          nhật, các ngày lễ, Tết. Thời gian giao hàng có thể bị ảnh hưởng bởi
          các yếu tố bất khả kháng như thời tiết, dịch bệnh...
        </p>

        <h2>3. Biểu Phí Vận Chuyển</h2>
        <ul>
          <li>
            <strong>Đồng giá toàn quốc:</strong> 30.000 VNĐ cho mỗi đơn hàng.
          </li>
          <li>
            <strong>MIỄN PHÍ VẬN CHUYỂN (FREESHIP):</strong> Áp dụng cho tất cả
            các đơn hàng có giá trị từ <strong>1.000.000 VNĐ</strong> trở lên.
          </li>
        </ul>
        <p>
          Phí vận chuyển sẽ được hiển thị rõ ràng ở bước thanh toán cuối cùng để
          quý khách xác nhận.
        </p>

        <h2>4. Kiểm Tra Hàng Hóa</h2>
        <p>
          Để đảm bảo quyền lợi khách hàng, TheAnhSneaker áp dụng chính sách
          <strong>Ship COD (nhận hàng - thanh toán)</strong> và cho phép khách
          hàng <strong>đồng kiểm</strong> với nhân viên giao hàng.
        </p>
        <ul>
          <li>
            Quý khách được quyền mở hộp hàng để kiểm tra đúng mẫu mã, đúng size,
            tình trạng sản phẩm trước khi thanh toán.
          </li>
          <li>
            Nếu phát hiện sản phẩm bị lỗi, sai mẫu, hoặc không đúng như mô tả,
            quý khách có quyền từ chối nhận hàng và không phải trả bất kỳ chi
            phí nào.
          </li>
          <li>
            <strong>Lưu ý quan trọng:</strong> Quý khách chỉ được kiểm tra,
            không được đi thử sản phẩm vào chân.
          </li>
        </ul>

        <div style="text-align: center">
          <a href="/" class="back-to-home">Quay Lại Trang Chủ</a>
        </div>
      </div>
    </main>

    <footer class="policy-footer">
      <p>© 2025 Bản quyền thuộc về TheAnhSneaker.</p>
    </footer>
  </body>
</html>
